var count = 23;
count++;

console.log("this data is from app.js");
console.log("count= "+ count);



        var result = 76;
        if(result<=100){
            console.log("value is less than 100");
        }
        else{
            console.log("value is greater than 100");
        }
        console.log("internal javascript code");

        var onButtonClick= function(){
            alert("here button is clicked....");
        }

        var onwelcomeClick= function(){
            alert("welcome to client side event handling....");
        }